# Secrets Manifest — NAMES ONLY (Bootstrap Annex BA-3). Values NEVER appear in this repo.
| Name | Purpose | Destination | Read by | Owner | Rotation |
|---|---|---|---|---|---|
| GH_TOKEN_AGENTICFOUNDRYBOT | all agent commits/PRs (ADR-B000) | GitHub Actions secret + workspace-local file (see note) | gate-writer, handoff-check, all worker agents | <HUMAN> | 90d |
| LITELLM_MASTER_KEY | proxy admin — **Mode P fallback only; do not create under Mode S (ADR-B003)** | host env /etc/company/dispatcher.env | dispatcher, proxy | <HUMAN> | 90d |
| PROVIDER_KEY_PRIMARY | model provider — **Mode P fallback only; key exists but MUST NOT be placed under Mode S (ADR-B003)** | proxy container env_file | proxy only | <HUMAN> | 90d |
| PROVIDER_KEY_SECONDARY | fallback provider — **Mode P fallback only; key exists but MUST NOT be placed under Mode S (ADR-B003)** | proxy container env_file | proxy only | <HUMAN> | 90d |
| APPROVALS_CHANNEL_TOKEN | approvals capture | host env /etc/company/dispatcher.env | dispatcher | <HUMAN> | 90d |
Verification: existence-only checks (exit codes). Printing any value, even masked, is prohibited.

**Sandbox mount rule (learned in Phase 0):** OpenClaw blocks bind-mounting any
system path (/etc/*, credential stores, docker.sock) into a sandbox container.
The bot token file MUST live inside the agent's own workspace tree, e.g.
`~/company/.secrets/gh-token` (absolute path, no `~`, in the docker `binds` config —
JSON does not expand tildes). Add `.secrets/` to `.gitignore` before the token file
is ever created, and confirm the file mode is 600.
Governance: this placement is ADR-B002; the accepted risk is registered as v2 §86-C7.
Mode S (ACTIVE, ADR-B003) note: provider OAuth tokens are NOT secrets in this manifest — they live only in OpenClaw per-agent auth stores (`~/.openclaw/agents/<id>/agent/auth-profiles.json`), created by human sign-in, refreshed automatically, never in the repo, never in any workspace.
