# Hardening Evidence — v2.1 §85 (task B0.1). Human completes; commit precedes ANY activation.
| # | Item | Evidence (command output ref / screenshot path / config commit) | Date | Done |
|---|------|---|---|---|
| 1 | Version floor incl. fixes for CVE-2026-25253 and CVE-2026-32922; weekly advisory SOP active | | | [ ] |
| 2 | Gateway auth enabled; no default/empty/shared tokens | | | [ ] |
| 3 | Loopback bind; Tailscale/SSH-tunnel only; external exposure check performed | | | [ ] |
| 4 | Per-agent containers; scoped mounts; egress allowlist; read-only roots where practical | | | [ ] |
| 5 | Skills vendored-only; review checklist in force; hashes pinned | | | [ ] |
| 6 | Per-agent scoped credentials; no broad OAuth/browser-profile grants; prod creds only in DCE path | | | [ ] |
| 7 | Browser/host-exec plugins disabled by default | | | [ ] |
| 8 | Dedicated VM/user; default-deny inbound firewall; patched OS; off-host repo backups | | | [ ] |
| 9 | Kill switch installed and drilled | | | [ ] |
