# Hardening Evidence — v2.1 §85 (task B0.1). Human completes; commit precedes ANY activation.
| # | Item | Evidence (command output ref / screenshot path / config commit) | Date | Done |
|---|------|---|---|---|
| 1 | Version floor incl. fixes for CVE-2026-25253 and CVE-2026-32922; weekly advisory SOP active | | | [ ] |
| 2 | Gateway auth enabled; no default/empty/shared tokens | | | [ ] |
| 3 | Loopback bind; Tailscale/SSH-tunnel only; external exposure check performed | | | [ ] |
| 4 | Per-agent containers; scoped mounts; egress allowlist; read-only roots where practical | | | [ ] |
| 5 | Skills vendored-only; review checklist in force; hashes pinned | | | [ ] |
| 6 | Per-agent scoped credentials; no broad OAuth/browser-profile grants; prod creds only in DCE path | | | [ ] |
| 7 | Browser/host-exec plugins disabled by default | | | [ ] |
| 8 | Dedicated VM/user; default-deny inbound firewall; patched OS; off-host repo backups | | | [ ] |
| 9 | Kill switch installed and drilled | | | [ ] |

Row guidance (field-validated 2026-07-15, OpenClaw 2026.7.1 — see PHASE-0-RUNBOOK v4.1 Step 4):
- Row 1: `openclaw --version` output; latest stable at provisioning is the floor. Record `claude --version` too (setup-token mint, BA-4).
- Row 2: gateway auth ON + token held as a **file SecretRef** (never plaintext in openclaw.json); rotation = regenerate the file (`openssl rand -hex 32`) + `openclaw gateway restart`. Dashboard auto-auth is disabled for SecretRef tokens by design.
- Row 5: doctor's "Eligible: N" counts *bundled platform* skills, not installs — the evidence claim is zero **installed** skills; set an allowlist to deny-all if the build supports one.
- Row 6: Mode S custody = Anthropic setup-token (long-lived; password-manager copy + rotation reminder) + OpenAI OAuth (auto-refresh) in per-agent auth stores. Record the accepted `secrets audit --check` baseline (plaintext=1 setup-token + legacy=1 OAuth). Command owner: unset is correct at zero channels; becomes mandatory with the first channel. Provider API keys exist but are never placed (ADR-B003).
